#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════╗
║         MATCHMOVE — Générateur de Dashboard Automatique      ║
║         Usage : python generer_dashboard.py                  ║
╚══════════════════════════════════════════════════════════════╝

Place ce script dans le même dossier que tes fichiers Excel :
  - KPI_SALES_MATCHMOVE_*.xlsx
  - KPI_OPS_MATCHMOVE_*.xlsx

Le script génère : dashboard_matchmove.html
"""

import os
import sys
import glob
import json
from datetime import datetime

# ─── VÉRIFICATION DÉPENDANCES ──────────────────────────────────────────────────
try:
    import openpyxl
except ImportError:
    print("❌ openpyxl non installé. Lance : pip install openpyxl")
    sys.exit(1)

# ─── CONFIGURATION ─────────────────────────────────────────────────────────────
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

def find_file(pattern):
    """Cherche un fichier Excel par pattern dans le dossier du script."""
    matches = glob.glob(os.path.join(SCRIPT_DIR, pattern))
    if not matches:
        return None
    return sorted(matches)[-1]  # Prend le plus récent si plusieurs

SALES_FILE = find_file("KPI_SALES*.xlsx") or find_file("*SALES*.xlsx")
OPS_FILE   = find_file("KPI_OPS*.xlsx")   or find_file("*OPS*.xlsx")

print("╔══════════════════════════════════════════════════╗")
print("║     MATCHMOVE — Génération du Dashboard          ║")
print("╚══════════════════════════════════════════════════╝")
print()

if not SALES_FILE:
    print("❌ Fichier SALES introuvable. Renomme-le pour qu'il contienne 'SALES'.")
    sys.exit(1)
if not OPS_FILE:
    print("❌ Fichier OPS introuvable. Renomme-le pour qu'il contienne 'OPS'.")
    sys.exit(1)

print(f"✅ Fichier Sales : {os.path.basename(SALES_FILE)}")
print(f"✅ Fichier OPS   : {os.path.basename(OPS_FILE)}")
print()

# ─── CONSTANTES ────────────────────────────────────────────────────────────────
EXCLUDE_KEYWORDS = ['TARGET','OBJECTIF','OBJ','TOTAL','CA ','RESTE','SALES',
                    'COMMISSION','JOURS','MARGE','BASSE','HAUTE','APX',
                    'LEADS','MONTH','DONE','PRIME','URL','PRESTA',
                    'CLIENT','PRIX','FOURNISSEUR','NOM','CHIFFRE','OBJECTI']

SALES_AGENTS = ['HIND','IMED','ASHWAK','SANNA','MARWA H','MARWA','OUMAYMA',
                'NADIA','MOLKA','SOUMAYA','ALEXIS','AIMAN','PIERRE']

OPS_AGENTS_MAP = {
    'MEHDI': 'MEHDI', 'IMED': 'IMED', 'MARWA': 'MARWA DÉBARRAS', 'AMENI': 'AMENI'
}

# ─── FONCTIONS UTILITAIRES ─────────────────────────────────────────────────────
def is_valid_client(v):
    if not v or not isinstance(v, str): return False
    v = v.strip()
    if len(v) < 3 or v.startswith('http'): return False
    vu = v.upper()
    for kw in EXCLUDE_KEYWORDS:
        if vu.startswith(kw): return False
    # Filtre les entrées style "15K", "20K" (tables de commission)
    if v.replace('K','').replace('k','').strip().isdigit(): return False
    return True

def is_valid_price(v):
    return isinstance(v, (int, float)) and 10 < float(v) < 100000

def normalize_sales_agent(name):
    if not name or not isinstance(name, str): return None
    n = name.strip().upper()
    for ag in SALES_AGENTS:
        if ag in n: return ag
    return None

def normalize_ops_agent(name):
    if not name or not isinstance(name, str): return None
    n = name.strip().upper()
    for key, val in OPS_AGENTS_MAP.items():
        if key in n: return val
    return None

def normalize_provider(v):
    if not v or not isinstance(v, str): return 'Autre'
    v = v.strip().upper()
    if 'MOVINGA' in v or 'MOUVINGA' in v: return 'Movinga'
    if 'OFFICIEL' in v or 'ODD' in v:     return 'Officiel du Dém.'
    if 'ALLO' in v and 'DEM' in v:        return 'Allo Dém.'
    if 'SUPER DEB' in v or 'SUPER DÉBAR' in v: return 'Super Débarras'
    if 'MES ALLOC' in v or 'MESALLOC' in v:    return 'Mes Alloc'
    if 'MAISON DEB' in v or 'MAISON DÉB' in v: return 'Maison Débarras'
    if 'BON DEB' in v or 'BON DÉB' in v:       return 'Bon Débarras'
    if v.startswith('LAD') or 'LADEMAIN' in v:  return 'LAD'
    if 'SELF STOCK' in v:   return 'Self Stock'
    if 'MYJUGAAD' in v:     return 'Myjugaad'
    if 'DÉBARRAS MATCHMOVE ADS' in v or 'DEBARRAS MATCHMOVE ADS' in v: return 'Matchmove ADS'
    if 'DÉBARRAS MATCHMOVE SEO' in v or 'DEBARRAS MATCHMOVE SEO' in v: return 'Matchmove SEO'
    if 'MATCHMOVE DÉM' in v or 'MATCHMOVE DEM' in v: return 'Matchmove Déménagement'
    if 'MATCHMOVE' in v or 'MMD' in v or 'DEM 24' in v: return 'Matchmove Direct'
    if 'AGENCE IMMO' in v:  return 'Agence Immo Part.'
    return 'Autre'

def normalize_ops_presta(v):
    if not v or not isinstance(v, str): return 'Autre'
    v = v.strip().upper()
    if 'SM DEM' in v or 'SMDEM' in v:    return 'SM DEM'
    if 'AMINI' in v:                      return 'Amini Transport'
    if 'SMAIL' in v or 'MEZAH' in v:     return 'Smail Mezahim'
    if 'ANDREY' in v or ('GAN' in v and 'ANDREY' in v): return 'Andrey Gan'
    if 'PROBEN' in v:                     return 'Proben'
    if 'KBR' in v or 'KEBIR' in v or 'YANIS' in v: return 'Yanis KBR'
    if 'MASTODONTE' in v or 'MASTODON' in v: return 'Les Mastodontes'
    if 'MOUFFOK' in v:                    return 'Mohamed Mouffok'
    if 'MILAN' in v:                      return 'Milan'
    if 'IWI' in v:                        return 'IWI Transports'
    if 'LBG' in v:                        return 'LBG Dém.'
    if 'ANANAS' in v:                     return 'Ananas Dém.'
    if 'CHAWKI' in v:                     return 'Chawki Abidi'
    if 'ALTEKA' in v or 'ALTÉKA' in v:   return 'Alteka'
    return 'Autre'

def month_label(sheet_name):
    """Convertit le nom d'onglet en étiquette lisible."""
    n = sheet_name.strip()
    mapping = {
        'Mai 2024':'Mai 24','Juin 2024':'Juin 24','Juillet 2024':'Juil 24',
        'Aout 2024':'Août 24','Septembre 2024':'Sep 24','octobre 2024':'Oct 24',
        'Novembre 2024':'Nov 24','Décembre 2024':'Déc 24','Janvier 2025':'Jan 25',
        'Février 2025 ':'Fév 25','Mars 2025':'Mar 25','Avril 2025':'Avr 25',
        'Mai 2025':'Mai 25','Juin 2025':'Juin 25','Juillet 2025':'Juil 25',
        'Aout 2025':'Août 25','Septembre 2025':'Sep 25','Octobre  2025':'Oct 25',
        'Novembre 2025':'Nov 25','Déc 2025':'Déc 25','Janvier 2026':'Jan 26',
        'FÉVRIER 2026':'Fév 26',
        # OPS
        'Février 2025':'Fév 25','Mars 2025':'Mar 25','Avril 2025':'Avr 25',
        'Juillet 2025':'Juil 25','Sept2025':'Sep 25','otc2025':'Oct 25',
        'Nov2025':'Nov 25','FEV 2026':'Fév 26',
    }
    return mapping.get(n, n)

def month_sort_key(label):
    order = ['Mai 24','Juin 24','Juil 24','Août 24','Sep 24','Oct 24','Nov 24','Déc 24',
             'Jan 25','Fév 25','Mar 25','Avr 25','Mai 25','Juin 25','Juil 25','Août 25',
             'Sep 25','Oct 25','Nov 25','Déc 25','Jan 26','Fév 26','Mar 26']
    return order.index(label) if label in order else 99

# ─── PARSING SALES ─────────────────────────────────────────────────────────────
print("⏳ Lecture du fichier Sales...")

wb_sales = openpyxl.load_workbook(SALES_FILE, data_only=True)
sales_monthly   = {}   # {month_label: {agent: ca}}
provider_stats  = {}   # {provider: {ca, count, agents}}
annulations_sales = [] # [{month, client, ca, provider}]

for sname in wb_sales.sheetnames:
    ws = wb_sales[sname]
    rows = list(ws.iter_rows(values_only=True))
    if not rows: continue
    label = month_label(sname)

    header_row = rows[0]
    row2 = rows[1] if len(rows) > 1 else []

    # Trouver les blocs agents dans la ligne 1
    blocks = []
    for ci, val in enumerate(header_row):
        agent = normalize_sales_agent(str(val) if val else '')
        if agent:
            blocks.append((agent, ci))

    for i, (agent, start_col) in enumerate(blocks):
        end_col = blocks[i+1][1] if i+1 < len(blocks) else min(start_col+14, len(header_row))

        # Détecter les colonnes prix/provider dans row2
        prix_col = prov_col = None
        for ci in range(start_col, min(end_col, len(row2))):
            val = str(row2[ci]).strip().upper() if row2[ci] else ''
            if 'PRIX' in val and 'HT' in val and prix_col is None:
                prix_col = ci
            if 'PROVIDER' in val or 'PROVID' in val:
                prov_col = ci

        if prix_col is None:
            val_1 = str(row2[start_col+1]).upper() if len(row2)>start_col+1 and row2[start_col+1] else ''
            if 'PROVID' in val_1:
                prov_col = start_col+1; prix_col = start_col+2
            else:
                prov_col = start_col+2; prix_col = start_col+3
        if prov_col is None:
            prov_col = start_col+1

        # Lire les données (annulations parsées séparément)
        for ri, row in enumerate(rows[2:], start=2):
            client_val = row[start_col] if len(row)>start_col else None
            prix_val   = row[prix_col]  if len(row)>prix_col   else None
            prov_val   = row[prov_col]  if len(row)>prov_col   else None
            if not is_valid_client(client_val) or not is_valid_price(prix_val): continue
            ca   = float(prix_val)
            prov = normalize_provider(str(prov_val) if prov_val else '')
            if label not in sales_monthly: sales_monthly[label] = {}
            sales_monthly[label][agent] = sales_monthly[label].get(agent, 0) + ca
            if prov not in provider_stats: provider_stats[prov] = {'ca':0,'count':0,'agents':set()}
            provider_stats[prov]['ca'] += ca; provider_stats[prov]['count'] += 1; provider_stats[prov]['agents'].add(agent)

# Sérialiser les sets
for p in provider_stats:
    provider_stats[p]['agents'] = list(provider_stats[p]['agents'])
    provider_stats[p]['ca']     = round(provider_stats[p]['ca'], 2)

# ─── PARSING ANNULATIONS SALES (zone col 12-17) ─────────────────────────────
annulations_sales = []
for sname in wb_sales.sheetnames:
    ws = wb_sales[sname]
    rows = list(ws.iter_rows(values_only=True))
    if not rows: continue
    label = month_label(sname)

    # Mai 2025 structure spéciale
    if 'Mai 2025' in sname:
        in_ann = False
        for ri, row in enumerate(rows):
            val = row[11] if len(row)>11 else None
            if val and isinstance(val, str) and 'Annulation' in val:
                in_ann = True; continue
            if in_ann:
                client = row[12] if len(row)>12 else None
                prix   = row[15] if len(row)>15 else None
                prov   = row[14] if len(row)>14 else None
                if client is None: continue
                if not isinstance(client, str) or len(client.strip()) < 3: continue
                if isinstance(prix, (int, float)) and 50 < prix < 100000:
                    annulations_sales.append({'month':label,'client':str(client).strip(),
                        'ca':round(float(prix),2),'provider':normalize_provider(str(prov) if prov else ''),'agent':'?'})
        continue

    # Structure normale : ANNULATION header en col 12
    in_ann = False
    for ri, row in enumerate(rows):
        val12 = row[12] if len(row)>12 else None
        if val12 and isinstance(val12, str) and 'ANNUL' in val12.upper():
            in_ann = True; continue
        if in_ann:
            client = row[12] if len(row)>12 else None
            prov   = row[14] if len(row)>14 else None
            prix   = row[15] if len(row)>15 else None
            agent  = row[17] if len(row)>17 else None
            if client is None: continue
            if isinstance(client, str) and client.strip() in ['URL CLIENT ','URL CLIENT','']: continue
            if isinstance(client, (int, float)): break
            if isinstance(client, str) and len(client.strip()) <= 4 and any(c.isdigit() for c in client): break
            if isinstance(client, str) and 'COM ' in client.upper(): break
            if isinstance(client, str) and len(client.strip()) < 3: continue
            if isinstance(prix, (int, float)) and 50 < prix < 100000:
                annulations_sales.append({'month':label,'client':str(client).strip(),
                    'ca':round(float(prix),2),'provider':normalize_provider(str(prov) if prov else ''),
                    'agent':str(agent).strip() if agent and isinstance(agent, str) else '?'})

# Deduplicate annulations sales
seen = set(); ann_s_dedup = []
for a in annulations_sales:
    key = (a['client'], a['month'])
    if key not in seen: seen.add(key); ann_s_dedup.append(a)
annulations_sales = sorted(ann_s_dedup, key=lambda x:-x['ca'])


# ─── PARSING OPS ───────────────────────────────────────────────────────────────
print("⏳ Lecture du fichier OPS...")

wb_ops = openpyxl.load_workbook(OPS_FILE, data_only=True)
ops_monthly    = {}   # {month_label: {agent: {ca, marge}}}
ops_prestas    = {}   # {presta: {ca, cost, count}}
annulations_ops= []   # [{month, client, ca, agent}]

for sname in wb_ops.sheetnames:
    ws = wb_ops[sname]
    rows = list(ws.iter_rows(values_only=True))
    if not rows: continue
    label = month_label(sname)

    header_row = rows[0]
    row2 = rows[1] if len(rows)>1 else []

    blocks = []
    for ci, val in enumerate(header_row):
        agent = normalize_ops_agent(str(val) if val else '')
        if agent:
            blocks.append((agent, ci))

    for i, (agent, start_col) in enumerate(blocks):
        end_col = blocks[i+1][1] if i+1 < len(blocks) else min(start_col+14, len(header_row))

        # Trouver colonnes
        prix_client_col = presta_col = prix_presta_col = None
        for ci in range(start_col, min(end_col, len(row2))):
            val = str(row2[ci]).upper() if row2[ci] else ''
            if 'PRIX' in val and 'CLIENT' in val: prix_client_col = ci
            elif 'PRIX' in val and 'PRESTA' in val: prix_presta_col = ci
            elif 'URL' in val and 'PRESTA' in val: presta_col = ci

        if prix_client_col is None: prix_client_col = start_col+2
        if prix_presta_col is None: prix_presta_col = start_col+3
        if presta_col is None:      presta_col      = start_col+1

        for ri, row in enumerate(rows[2:], start=2):
            client_val     = row[start_col]         if len(row)>start_col         else None
            prix_client    = row[prix_client_col]   if len(row)>prix_client_col   else None
            prix_presta_v  = row[prix_presta_col]   if len(row)>prix_presta_col   else None
            presta_v       = row[presta_col]         if len(row)>presta_col         else None

            if not is_valid_client(client_val) or not is_valid_price(prix_client): continue
            ca    = float(prix_client)
            cost  = float(prix_presta_v) if is_valid_price(prix_presta_v) else 0
            pname = normalize_ops_presta(str(presta_v) if presta_v else '')

            if label not in ops_monthly: ops_monthly[label] = {}
            if agent not in ops_monthly[label]: ops_monthly[label][agent] = {'ca':0,'marge':0}
            ops_monthly[label][agent]['ca']    += ca
            ops_monthly[label][agent]['marge'] += ca - cost
            if pname not in ops_prestas: ops_prestas[pname] = {'ca':0,'cost':0,'count':0}
            ops_prestas[pname]['ca'] += ca; ops_prestas[pname]['cost'] += cost; ops_prestas[pname]['count'] += 1

# ─── PARSING ANNULATIONS OPS (col 0) ────────────────────────────────────────
annulations_ops = []
for sname in wb_ops.sheetnames:
    ws = wb_ops[sname]
    rows = list(ws.iter_rows(values_only=True))
    if not rows: continue
    label = month_label(sname)
    in_ann = False
    for ri, row in enumerate(rows):
        val = row[0] if len(row)>0 else None
        if val and isinstance(val, str) and 'ANNUL' in val.upper():
            in_ann = True; continue
        if in_ann:
            client = row[0] if len(row)>0 else None
            prix   = row[3] if len(row)>3 else None
            agent  = row[5] if len(row)>5 else None
            if client is None: continue
            if isinstance(client, str) and client.strip() in ['URL CLIENT ','URL CLIENT','']: continue
            if isinstance(client, str) and len(client.strip()) < 3: continue
            if isinstance(prix, (int, float)) and 50 < prix < 100000:
                annulations_ops.append({'month':label,'client':str(client).strip(),
                    'ca':round(float(prix),2),
                    'agent':str(agent).strip().upper() if agent and isinstance(agent,str) else '?'})
seen=set(); ann_o_dedup=[]
for a in annulations_ops:
    key=(a['client'],a['month'])
    if key not in seen: seen.add(key); ann_o_dedup.append(a)
annulations_ops = sorted(ann_o_dedup, key=lambda x:-x['ca'])

# ─── CALCUL DES TOTAUX ─────────────────────────────────────────────────────────
def calc_totals(ops_monthly):
    agent_totals = {}
    for month, agents in ops_monthly.items():
        for agent, d in agents.items():
            if agent not in agent_totals: agent_totals[agent] = {'ca':0,'marge':0,'months':0}
            agent_totals[agent]['ca']    += d['ca']
            agent_totals[agent]['marge'] += d['marge']
            agent_totals[agent]['months'] += 1
    return agent_totals

def calc_sales_totals(sales_monthly):
    agent_totals = {}
    for month, agents in sales_monthly.items():
        for agent, ca in agents.items():
            agent_totals[agent] = agent_totals.get(agent, 0) + ca
    return agent_totals

ops_agent_totals   = calc_totals(ops_monthly)
sales_agent_totals = calc_sales_totals(sales_monthly)

# Totaux globaux
total_ops_ca    = sum(d['ca']    for d in ops_agent_totals.values())
total_ops_marge = sum(d['marge'] for d in ops_agent_totals.values())
total_sales_ca  = sum(sales_agent_totals.values())

# Annulations nettoyées
def clean_ann(ann_list):
    return [a for a in ann_list if is_valid_client(a['client']) and a['ca'] > 50]

ann_sales_clean = clean_ann(annulations_sales)
ann_ops_clean   = clean_ann(annulations_ops)
total_ann_sales = sum(a['ca'] for a in ann_sales_clean)
total_ann_ops   = sum(a['ca'] for a in ann_ops_clean)

# Tri par mois
sorted_ops_months   = sorted(ops_monthly.keys(),   key=month_sort_key)
sorted_sales_months = sorted(sales_monthly.keys(), key=month_sort_key)
sorted_providers    = sorted(provider_stats.items(), key=lambda x: -x[1]['ca'])
sorted_prestas      = sorted(ops_prestas.items(),    key=lambda x: -x[1]['count'])

print(f"✅ OPS   : {len(ops_monthly)} mois · CA total = {total_ops_ca:,.0f}€ · Marge = {total_ops_marge/total_ops_ca*100:.1f}%")
print(f"✅ Sales : {len(sales_monthly)} mois · CA total = {total_sales_ca:,.0f}€")
print(f"✅ Providers Sales : {len(provider_stats)}")
print(f"✅ Prestataires OPS : {len(ops_prestas)}")
print(f"✅ Annulations Sales : {len(ann_sales_clean)} dossiers · {total_ann_sales:,.0f}€")
print(f"✅ Annulations OPS  : {len(ann_ops_clean)}  dossiers · {total_ann_ops:,.0f}€")
print()
print("⏳ Génération du HTML...")

# ─── GÉNÉRATION HTML ───────────────────────────────────────────────────────────
# ── KPI GLOBAL (DEM vs DEB) ───────────────────────────────────────────────────
import openpyxl as _ox2
_kpi_wb = _ox2.load_workbook('/mnt/user-data/uploads/KPIs_Globaux_MatchMove.xlsx', data_only=True)
_MONTH_MAP = {'MAI':'Mai','JUIN':'Juin','JUILLET':'Juil','AOUT':'Août','SEPTEMBRE':'Sep',
    'OCTOBRE':'Oct','NOVEMBRE':'Nov','DECEMBRE':'Déc','JANVIER':'Jan',
    'FEVRIER':'Fév','MARS':'Mar','AVRIL':'Avr'}
_YM_ORDER = ["Mai 24", "Juin 24", "Juil 24", "Août 24", "Sep 24", "Oct 24", "Nov 24", "Déc 24", "Jan 25", "Fév 25", "Mar 25", "Avr 25", "Mai 25", "Juin 25", "Juil 25", "Août 25", "Sep 25", "Oct 25", "Nov 25", "Déc 25", "Jan 26", "Fév 26", "Mar 26"]
def _parse_kpi_sheet(ws, yr):
    rows = list(ws.iter_rows(values_only=True)); res = {}; i=0
    while i < len(rows):
        row=rows[i]; mc={}
        for ci,val in enumerate(row):
            if isinstance(val,str) and val.strip().upper().replace(' ','') in _MONTH_MAP:
                mc[ci]=_MONTH_MAP[val.strip().upper().replace(' ','')]
        if mc:
            br=rows[i+1:i+9]
            for ci,mn in mc.items():
                lbl=f'{mn} {yr}'; ca_dem=marge_dem=ca_deb=marge_deb=n=0
                for r in br:
                    l=r[ci] if len(r)>ci and r[ci] else None; v=r[ci+1] if len(r)>ci+1 else None
                    if not l or not isinstance(l,str): continue
                    lu=l.strip().upper()
                    if lu.startswith('CA DEM'): ca_dem=float(v or 0)
                    elif lu.startswith('MARGE DEM'): marge_dem=float(v or 0)
                    elif lu.startswith('CA DEB'): ca_deb=float(v or 0)
                    elif lu.startswith('MARGE DEB'): marge_deb=float(v or 0)
                    elif lu.startswith('NOMBRE'): n=int(float(v or 0))
                if ca_dem>0 or ca_deb>0:
                    res[lbl]=dict(ca_dem=ca_dem,marge_dem=marge_dem,
                                  ca_deb=ca_deb,marge_deb=marge_deb,n=n)
        i+=1
    return res
_kpi={}
_kpi.update(_parse_kpi_sheet(_kpi_wb['2024'],'24'))
_kpi.update(_parse_kpi_sheet(_kpi_wb['2025'],'25'))
_kpi.update(_parse_kpi_sheet(_kpi_wb['2026'],'26'))
kpi_global = {k:_kpi[k] for k in _YM_ORDER if k in _kpi}
kpi_months = list(kpi_global.keys())
print(f"✅ KPI Global : {len(kpi_global)} mois parsés (DEM + DEB)")

ops_monthly_js    = json.dumps(ops_monthly,    ensure_ascii=False)
sales_monthly_js  = json.dumps(sales_monthly,  ensure_ascii=False)
providers_js      = json.dumps([{'name':k,'ca':v['ca'],'count':v['count'],'agents':v['agents']} for k,v in sorted_providers], ensure_ascii=False)
prestas_js        = json.dumps([{'name':k,'ca':v['ca'],'cost':v['cost'],'count':v['count']} for k,v in sorted_prestas], ensure_ascii=False)
ann_sales_js      = json.dumps(sorted(ann_sales_clean, key=lambda x: -x['ca']), ensure_ascii=False)
ann_ops_js        = json.dumps(sorted(ann_ops_clean,   key=lambda x: -x['ca']), ensure_ascii=False)
kpi_global_js     = json.dumps(kpi_global,     ensure_ascii=False)
kpi_months_js     = json.dumps(kpi_months,     ensure_ascii=False)
ops_months_js     = json.dumps(sorted_ops_months,   ensure_ascii=False)
sales_months_js   = json.dumps(sorted_sales_months, ensure_ascii=False)
generated_at      = datetime.now().strftime("%d/%m/%Y %H:%M")

html = f"""<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard Matchmove — {generated_at}</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;700;800&family=DM+Mono:wght@300;400;500&display=swap" rel="stylesheet">
<style>
:root {{
  --bg:#0a0a0f; --surface:#12121a; --surface2:#1a1a28; --border:#2a2a3d;
  --accent:#7c5cfc; --accent2:#f7c948; --accent3:#3ecf8e; --danger:#ff4d6d;
  --text:#e8e8f0; --muted:#6b6b8a;
  --font-display:'Syne',sans-serif; --font-mono:'DM Mono',monospace;
}}
*{{margin:0;padding:0;box-sizing:border-box;}}
body{{background:var(--bg);color:var(--text);font-family:var(--font-mono);min-height:100vh;}}
body::before{{content:'';position:fixed;inset:0;background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.03'/%3E%3C/svg%3E");pointer-events:none;z-index:0;}}
.header{{padding:28px 40px 22px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:100;background:rgba(10,10,15,0.95);backdrop-filter:blur(12px);}}
.logo{{font-family:var(--font-display);font-size:22px;font-weight:800;letter-spacing:-0.5px;}}
.logo span{{color:var(--accent);}}
.header-meta{{font-size:11px;color:var(--muted);letter-spacing:2px;text-transform:uppercase;}}
.main{{padding:32px 40px;position:relative;z-index:1;}}
.filters{{display:flex;gap:12px;flex-wrap:wrap;margin-bottom:32px;padding:20px;background:var(--surface);border:1px solid var(--border);border-radius:12px;}}
.filter-group{{display:flex;flex-direction:column;gap:6px;min-width:155px;}}
.filter-label{{font-size:10px;letter-spacing:2px;color:var(--muted);text-transform:uppercase;}}
select,.btn{{background:var(--surface2);border:1px solid var(--border);color:var(--text);font-family:var(--font-mono);font-size:13px;padding:8px 14px;border-radius:8px;cursor:pointer;outline:none;transition:border-color .2s;}}
select:hover,select:focus{{border-color:var(--accent);}}
.btn{{background:var(--accent);border-color:var(--accent);color:white;font-weight:500;align-self:flex-end;padding:9px 20px;}}
.btn:hover{{opacity:.85;}}
.kpis{{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:16px;margin-bottom:32px;}}
.kpi-card{{background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:22px 18px;position:relative;overflow:hidden;transition:transform .2s,border-color .2s;}}
.kpi-card:hover{{transform:translateY(-2px);border-color:var(--accent);}}
.kpi-card::before{{content:'';position:absolute;top:0;left:0;right:0;height:3px;background:var(--accent-color,var(--accent));}}
.kpi-label{{font-size:10px;letter-spacing:2px;color:var(--muted);text-transform:uppercase;margin-bottom:10px;}}
.kpi-value{{font-family:var(--font-display);font-size:30px;font-weight:800;letter-spacing:-1px;}}
.kpi-sub{{font-size:11px;color:var(--muted);margin-top:4px;}}
.tabs{{display:flex;flex-wrap:wrap;gap:0;margin-bottom:20px;border-bottom:1px solid var(--border);}}
.tab{{padding:10px 18px;font-family:var(--font-mono);font-size:11px;letter-spacing:1px;text-transform:uppercase;cursor:pointer;border-bottom:2px solid transparent;color:var(--muted);transition:all .2s;background:none;border-top:none;border-left:none;border-right:none;white-space:nowrap;}}
.tab.active{{color:var(--accent);border-bottom-color:var(--accent);}}
.tab:hover:not(.active){{color:var(--text);}}
.tab-panel{{display:none;}}
.tab-panel.active{{display:block;}}
.grid-2{{display:grid;grid-template-columns:1fr 1fr;gap:20px;}}
.grid-3{{display:grid;grid-template-columns:repeat(3,1fr);gap:20px;}}
@media(max-width:1000px){{.grid-2,.grid-3{{grid-template-columns:1fr;}}}}
.chart-card{{background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:24px;}}
.chart-title{{font-size:12px;color:var(--muted);margin-bottom:16px;letter-spacing:1px;text-transform:uppercase;}}
.chart-wrap{{position:relative;height:280px;}}
.table-card{{background:var(--surface);border:1px solid var(--border);border-radius:12px;overflow:hidden;margin-bottom:24px;}}
.table-head{{padding:16px 20px;border-bottom:1px solid var(--border);}}
.table-head h3{{font-size:12px;color:var(--muted);letter-spacing:1px;text-transform:uppercase;}}
table{{width:100%;border-collapse:collapse;}}
th{{font-size:10px;letter-spacing:1.5px;color:var(--muted);text-transform:uppercase;text-align:left;padding:11px 16px;border-bottom:1px solid var(--border);background:var(--surface2);}}
td{{padding:10px 16px;font-size:13px;border-bottom:1px solid rgba(42,42,61,0.5);}}
tr:last-child td{{border-bottom:none;}}
tr:hover td{{background:rgba(124,92,252,0.05);}}
.badge{{display:inline-block;padding:3px 8px;border-radius:4px;font-size:11px;font-weight:500;}}
.badge-good{{background:rgba(62,207,142,0.15);color:var(--accent3);}}
.badge-warn{{background:rgba(247,201,72,0.15);color:var(--accent2);}}
.badge-bad{{background:rgba(255,77,109,0.15);color:var(--danger);}}
.badge-purple{{background:rgba(124,92,252,0.15);color:var(--accent);}}
.alert-box{{border-radius:12px;padding:22px;border:1px solid;margin-bottom:20px;}}
.alert-item{{display:flex;align-items:flex-start;gap:12px;margin-bottom:12px;}}
.alert-item:last-child{{margin-bottom:0;}}
.alert-icon{{font-size:17px;flex-shrink:0;margin-top:1px;}}
.alert-text strong{{display:block;font-family:var(--font-display);font-size:14px;font-weight:700;margin-bottom:3px;}}
.alert-text span{{font-size:12px;color:var(--muted);line-height:1.5;}}
.scatter-legend{{display:flex;gap:14px;flex-wrap:wrap;margin-bottom:10px;}}
.legend-item{{display:flex;align-items:center;gap:6px;font-size:11px;color:var(--muted);}}
.legend-dot{{width:10px;height:10px;border-radius:50%;}}
.ann-card{{background:rgba(255,77,109,0.06);border:1px solid rgba(255,77,109,0.2);border-radius:12px;padding:20px;margin-bottom:16px;}}
.ann-header{{font-family:var(--font-display);font-size:15px;font-weight:700;color:var(--danger);margin-bottom:14px;}}
.ann-row{{display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid rgba(255,77,109,0.1);font-size:13px;}}
.ann-row:last-child{{border:none;}}
.ann-ca{{color:var(--danger);font-weight:700;}}
.ann-meta{{font-size:11px;color:var(--muted);}}
.footer{{padding:20px 40px;border-top:1px solid var(--border);font-size:11px;color:var(--muted);letter-spacing:1px;}}
</style>
</head>
<body>
<header class="header">
  <div class="logo">Match<span>move</span> <span style="color:var(--muted);font-weight:400;font-size:15px">/ Dashboard Intelligence</span></div>
  <div class="header-meta">Généré le {generated_at} · Données auto</div>
</header>
<main class="main">

<!-- FILTRES -->
<div class="filters">
  <div class="filter-group">
    <div class="filter-label">Période OPS</div>
    <select id="f-period" onchange="applyFilters()">
      <option value="all">Toutes</option>
    </select>
  </div>
  <div class="filter-group">
    <div class="filter-label">Agent OPS</div>
    <select id="f-agent-ops" onchange="applyFilters()">
      <option value="all">Tous</option>
    </select>
  </div>
  <div class="filter-group">
    <div class="filter-label">Agent Sales</div>
    <select id="f-agent-sales" onchange="applyFilters()">
      <option value="all">Tous</option>
    </select>
  </div>
  <div class="filter-group">
    <div class="filter-label">Provider</div>
    <select id="f-provider" onchange="applyFilters()">
      <option value="all">Tous</option>
    </select>
  </div>
  <div class="filter-group" style="justify-content:flex-end">
    <button class="btn" onclick="resetFilters()">↺ Réinitialiser</button>
  </div>
</div>

<!-- KPIs -->
<div class="kpis">
  <div class="kpi-card" style="--accent-color:var(--accent)">
    <div class="kpi-label">CA OPS Total</div>
    <div class="kpi-value" id="kv-ops-ca">—</div>
    <div class="kpi-sub" id="ks-ops-ca">—</div>
  </div>
  <div class="kpi-card" style="--accent-color:var(--accent3)">
    <div class="kpi-label">Marge OPS</div>
    <div class="kpi-value" id="kv-ops-marge">—</div>
    <div class="kpi-sub" id="ks-ops-marge">—</div>
  </div>
  <div class="kpi-card" style="--accent-color:var(--accent2)">
    <div class="kpi-label">Chantiers OPS</div>
    <div class="kpi-value" id="kv-ops-chantiers">—</div>
    <div class="kpi-sub">dossiers traités</div>
  </div>
  <div class="kpi-card" style="--accent-color:#f97316">
    <div class="kpi-label">CA Sales Total</div>
    <div class="kpi-value" id="kv-sales-ca">—</div>
    <div class="kpi-sub" id="ks-sales-ca">—</div>
  </div>
  <div class="kpi-card" style="--accent-color:#06b6d4">
    <div class="kpi-label">Panier Moyen OPS</div>
    <div class="kpi-value" id="kv-panier">—</div>
    <div class="kpi-sub">par mois·agent</div>
  </div>
  <div class="kpi-card" style="--accent-color:var(--danger)">
    <div class="kpi-label">CA Annulé</div>
    <div class="kpi-value" style="color:var(--danger)" id="kv-ann">—</div>
    <div class="kpi-sub" id="ks-ann">—</div>
  </div>
</div>

<!-- TABS -->
<div class="tabs">
  <button class="tab active"  onclick="showTab('tab-ops',this)">📊 Rentabilité OPS</button>
  <button class="tab"         onclick="showTab('tab-agents-ops',this)">👤 Agents OPS</button>
  <button class="tab"         onclick="showTab('tab-sales',this)">💼 Agents Sales</button>
  <button class="tab"         onclick="showTab('tab-providers',this)">🏷️ Providers Sales</button>
  <button class="tab"         onclick="showTab('tab-prestas',this)">🔧 Prestataires OPS</button>
  <button class="tab"         onclick="showTab('tab-annulations',this)">❌ Annulations</button>
  <button class="tab"         onclick="showTab('tab-alertes',this)">🚨 Alertes</button>
  <button class="tab"         onclick="showTab('tab-segments',this)">📦 DEM vs DEB</button>
  <button class="tab"         onclick="showTab('tab-mckinsey',this)">📐 Décisions</button>
</div>

<!-- OPS GLOBAL -->
<div id="tab-ops" class="tab-panel active">
  <div class="grid-2" style="margin-bottom:24px">
    <div class="chart-card">
      <div class="chart-title">Évolution mensuelle — CA & Marge OPS</div>
      <div class="chart-wrap"><canvas id="ch-ops-monthly"></canvas></div>
    </div>
    <div class="chart-card">
      <div class="chart-title">Répartition CA par Agent OPS</div>
      <div class="chart-wrap"><canvas id="ch-ops-pie"></canvas></div>
    </div>
  </div>
  <div class="chart-card">
    <div class="chart-title">Top Prestataires — CA Client vs Coût Presta</div>
    <div class="chart-wrap" style="height:320px"><canvas id="ch-vc"></canvas></div>
  </div>
</div>

<!-- AGENTS OPS -->
<div id="tab-agents-ops" class="tab-panel">
  <div class="grid-2" style="margin-bottom:24px">
    <div class="chart-card">
      <div class="chart-title">Volume vs Marge — Agents OPS</div>
      <div class="scatter-legend" id="scatter-legend"></div>
      <div class="chart-wrap"><canvas id="ch-scatter"></canvas></div>
    </div>
    <div class="chart-card">
      <div class="chart-title">CA mensuel par Agent OPS</div>
      <div class="chart-wrap"><canvas id="ch-ops-agents-line"></canvas></div>
    </div>
  </div>
  <div class="table-card">
    <div class="table-head"><h3>Performance Agents OPS</h3></div>
    <table>
      <thead><tr><th>Agent</th><th>Mois actifs</th><th>CA Total</th><th>Coût Presta</th><th>Marge €</th><th>Marge %</th><th>CA moy/mois</th><th>Statut</th></tr></thead>
      <tbody id="tb-agents-ops"></tbody>
    </table>
  </div>
</div>

<!-- AGENTS SALES -->
<div id="tab-sales" class="tab-panel">
  <div class="grid-2" style="margin-bottom:24px">
    <div class="chart-card">
      <div class="chart-title">CA Sales par Agent — Classement général</div>
      <div class="chart-wrap"><canvas id="ch-sales-bar"></canvas></div>
    </div>
    <div class="chart-card">
      <div class="chart-title">Évolution mensuelle Sales — Agents actifs</div>
      <div class="chart-wrap"><canvas id="ch-sales-line"></canvas></div>
    </div>
  </div>
  <div class="table-card">
    <div class="table-head"><h3>Classement Agents Sales</h3></div>
    <table>
      <thead><tr><th>#</th><th>Agent</th><th>CA Total</th><th>Mois actifs</th><th>CA moy/mois</th><th>Statut</th></tr></thead>
      <tbody id="tb-sales-agents"></tbody>
    </table>
  </div>
</div>

<!-- PROVIDERS SALES -->
<div id="tab-providers" class="tab-panel">
  <div class="grid-2" style="margin-bottom:24px">
    <div class="chart-card">
      <div class="chart-title">CA par Provider d'apport</div>
      <div class="chart-wrap"><canvas id="ch-prov-ca"></canvas></div>
    </div>
    <div class="chart-card">
      <div class="chart-title">Volume dossiers par Provider</div>
      <div class="chart-wrap"><canvas id="ch-prov-vol"></canvas></div>
    </div>
  </div>
  <div class="table-card">
    <div class="table-head"><h3>Analyse Complète Providers Sales</h3></div>
    <table>
      <thead><tr><th>Provider</th><th>CA Total</th><th>Dossiers</th><th>Panier Moy.</th><th>Part du CA</th><th>Agents</th><th>Performance</th></tr></thead>
      <tbody id="tb-providers"></tbody>
    </table>
  </div>
  <div class="grid-2">
    <div class="chart-card">
      <div class="chart-title">Panier moyen par Provider</div>
      <div class="chart-wrap"><canvas id="ch-prov-panier"></canvas></div>
    </div>
    <div class="chart-card">
      <div class="chart-title">Répartition CA — Camembert</div>
      <div class="chart-wrap"><canvas id="ch-prov-pie"></canvas></div>
    </div>
  </div>
</div>

<!-- PRESTATAIRES OPS -->
<div id="tab-segments" class="tab-panel">
  <div class="kpi-row" id="seg-kpis"></div>
  <div class="chart-grid">
    <div class="chart-box chart-wide"><div class="chart-title">CA mensuel — Déménagement vs Débarras & Ménage</div><canvas id="segCaChart"></canvas></div>
    <div class="chart-box chart-wide"><div class="chart-title">Marge mensuelle — Déménagement vs Débarras & Ménage</div><canvas id="segMargeChart"></canvas></div>
    <div class="chart-box"><div class="chart-title">Répartition CA cumulé</div><canvas id="segDonutChart"></canvas></div>
    <div class="chart-box"><div class="chart-title">Marge % comparée par mois</div><canvas id="segMargePctChart"></canvas></div>
  </div>
  <div class="table-container" id="seg-table"></div>
</div>

<div id="tab-prestas" class="tab-panel">
  <div class="grid-2" style="margin-bottom:24px">
    <div class="chart-card">
      <div class="chart-title">Volume chantiers par Prestataire</div>
      <div class="chart-wrap"><canvas id="ch-presta-vol"></canvas></div>
    </div>
    <div class="chart-card">
      <div class="chart-title">Taux de marge par Prestataire</div>
      <div class="chart-wrap"><canvas id="ch-presta-marge"></canvas></div>
    </div>
  </div>
  <div class="table-card">
    <div class="table-head"><h3>Analyse Prestataires OPS</h3></div>
    <table>
      <thead><tr><th>Prestataire</th><th>Chantiers</th><th>CA Client</th><th>Coût Total</th><th>Marge €</th><th>Marge %</th><th>Coût moy/chantier</th><th>Performance</th></tr></thead>
      <tbody id="tb-prestas"></tbody>
    </table>
  </div>
</div>

<!-- ANNULATIONS -->
<div id="tab-annulations" class="tab-panel">
  <div class="kpis" style="grid-template-columns:repeat(4,1fr);margin-bottom:28px">
    <div class="kpi-card" style="--accent-color:var(--danger)">
      <div class="kpi-label">CA Perdu Sales</div>
      <div class="kpi-value" style="color:var(--danger)" id="ann-sales-total">—</div>
      <div class="kpi-sub" id="ann-sales-count">—</div>
    </div>
    <div class="kpi-card" style="--accent-color:var(--danger)">
      <div class="kpi-label">CA Perdu OPS</div>
      <div class="kpi-value" style="color:var(--danger)" id="ann-ops-total">—</div>
      <div class="kpi-sub" id="ann-ops-count">—</div>
    </div>
    <div class="kpi-card" style="--accent-color:var(--accent2)">
      <div class="kpi-label">Total Perdu</div>
      <div class="kpi-value" style="color:var(--accent2)" id="ann-total">—</div>
      <div class="kpi-sub">CA annulé cumulé</div>
    </div>
    <div class="kpi-card" style="--accent-color:var(--muted)">
      <div class="kpi-label">Taux d&#39;annulation</div>
      <div class="kpi-value" style="font-size:22px;color:var(--accent2)" id="ann-rate">—</div>
      <div class="kpi-sub">vs CA Sales total</div>
    </div>
  </div>
  <div class="grid-2" style="margin-bottom:24px">
    <div class="ann-card">
      <div class="ann-header">❌ Annulations Sales</div>
      <div id="ann-sales-list"></div>
    </div>
    <div>
      <div class="ann-card" style="margin-bottom:16px">
        <div class="ann-header" style="color:var(--accent2)">⚠️ Annulations OPS</div>
        <div id="ann-ops-list"></div>
      </div>
      <div class="chart-card">
        <div class="chart-title">Annulations Sales — Par Provider</div>
        <div class="chart-wrap" style="height:220px"><canvas id="ch-ann-prov"></canvas></div>
      </div>
    </div>
  </div>
  <div class="alert-box" style="background:rgba(255,77,109,0.06);border-color:rgba(255,77,109,0.25)">
    <div id="ann-analysis"></div>
  </div>
</div>

<!-- ALERTES -->
<div id="tab-alertes" class="tab-panel">
  <div id="alertes-container"></div>
</div>

<!-- MCKINSEY DECISIONS -->
<div id="tab-mckinsey" class="tab-panel">
  <div id="mckinsey-container"></div>
</div>

</main>
<footer class="footer">
  Dashboard Matchmove · Généré automatiquement le {generated_at} · Script v3
</footer>

<script>
Chart.defaults.color='#6b6b8a';
Chart.defaults.borderColor='#2a2a3d';
Chart.defaults.font.family="'DM Mono',monospace";

const OPS_MONTHLY   = {ops_monthly_js};
const SALES_MONTHLY = {sales_monthly_js};
const PROVIDERS     = {providers_js};
const PRESTAS       = {prestas_js};
const ANN_SALES     = {ann_sales_js};
const ANN_OPS       = {ann_ops_js};
const KPI_GLOBAL    = {kpi_global_js};
const KPI_MONTHS    = {kpi_months_js};
const OPS_MONTHS    = {ops_months_js};
const SALES_MONTHS  = {sales_months_js};

const PALETTE = ['rgba(124,92,252,0.8)','rgba(62,207,142,0.8)','rgba(247,201,72,0.8)',
  'rgba(255,77,109,0.8)','rgba(59,130,246,0.8)','rgba(251,146,60,0.8)',
  'rgba(217,70,239,0.8)','rgba(20,184,166,0.8)','rgba(234,179,8,0.8)',
  'rgba(239,68,68,0.8)','rgba(16,185,129,0.8)','rgba(99,102,241,0.8)'];

const fmt = n => new Intl.NumberFormat('fr-FR',{{style:'currency',currency:'EUR',minimumFractionDigits:2,maximumFractionDigits:2}}).format(n);
const fmtFull = n => new Intl.NumberFormat('fr-FR',{{style:'currency',currency:'EUR',minimumFractionDigits:2,maximumFractionDigits:2}}).format(n);
let charts={{}};
function dc(id){{if(charts[id]){{charts[id].destroy();delete charts[id];}}}}

// ── FILTRES ────────────────────────────────────────────────────────────────────
function populateFilters() {{
  const periods = document.getElementById('f-period');
  OPS_MONTHS.forEach(m => {{ const o=document.createElement('option'); o.value=o.textContent=m; periods.append(o); }});
  const opsAgents = [...new Set(OPS_MONTHS.flatMap(m=>Object.keys(OPS_MONTHLY[m]||{{}})))];
  const fao=document.getElementById('f-agent-ops');
  opsAgents.forEach(a=>{{ const o=document.createElement('option'); o.value=o.textContent=a; fao.append(o); }});
  const salesAgents=[...new Set(SALES_MONTHS.flatMap(m=>Object.keys(SALES_MONTHLY[m]||{{}})))];
  const fas=document.getElementById('f-agent-sales');
  salesAgents.forEach(a=>{{ const o=document.createElement('option'); o.value=o.textContent=a; fas.append(o); }});
  const fp=document.getElementById('f-provider');
  PROVIDERS.forEach(p=>{{ const o=document.createElement('option'); o.value=o.textContent=p.name; fp.append(o); }});
}}

function getFilteredOps() {{
  const period=document.getElementById('f-period').value;
  const agent=document.getElementById('f-agent-ops').value;
  let result=[]; let months=period==='all'?OPS_MONTHS:[period];
  months.forEach(m=>{{ if(!OPS_MONTHLY[m]) return;
    Object.entries(OPS_MONTHLY[m]).forEach(([ag,d])=>{{
      if(agent!=='all'&&ag!==agent) return;
      result.push({{month:m,agent:ag,ca:d.ca,marge:d.marge}});
    }});
  }});
  return result;
}}

function getFilteredSales() {{
  const agent=document.getElementById('f-agent-sales').value;
  const prov=document.getElementById('f-provider').value;
  let result=[];
  SALES_MONTHS.forEach(m=>{{ if(!SALES_MONTHLY[m]) return;
    Object.entries(SALES_MONTHLY[m]).forEach(([ag,ca])=>{{
      if(agent!=='all'&&ag!==agent) return;
      result.push({{month:m,agent:ag,ca}});
    }});
  }});
  return result;
}}

function resetFilters() {{
  ['f-period','f-agent-ops','f-agent-sales','f-provider'].forEach(id=>document.getElementById(id).value='all');
  applyFilters();
}}

function applyFilters() {{
  const ops=getFilteredOps(); const sales=getFilteredSales();
  updateKPIs(ops,sales);
  renderOpsMonthly(ops); renderOpsPie(ops); renderVC();
  renderScatter(ops); renderOpsAgentsLine(ops); renderTableAgentsOps(ops);
  renderSalesBar(sales); renderSalesLine(sales); renderTableSales(sales);
  renderProviders(); renderTableProviders();
  renderPrestas(); renderTablePrestas();
  renderAnnulations();
  renderAlertes(ops,sales);
  renderMcKinsey(ops,sales);
  renderSegments();
}}

// ── KPIs ───────────────────────────────────────────────────────────────────────
function updateKPIs(ops,sales) {{
  const tCA=ops.reduce((s,r)=>s+r.ca,0);
  const tM=ops.reduce((s,r)=>s+r.marge,0);
  const tS=sales.reduce((s,r)=>s+r.ca,0);
  const mp=tCA>0?(tM/tCA*100).toFixed(1):0;
  const annTotal=(ANN_SALES.reduce((s,a)=>s+a.ca,0)+ANN_OPS.reduce((s,a)=>s+a.ca,0));
  document.getElementById('kv-ops-ca').textContent=fmt(tCA);
  document.getElementById('ks-ops-ca').textContent='Coût: '+fmt(tCA-tM);
  document.getElementById('kv-ops-marge').textContent=mp+'%';
  document.getElementById('ks-ops-marge').textContent=fmtFull(tM)+' générés';
  document.getElementById('kv-ops-chantiers').textContent=ops.length||'—';
  document.getElementById('kv-sales-ca').textContent=fmt(tS);
  document.getElementById('ks-sales-ca').textContent=sales.length+' enregistrements';
  document.getElementById('kv-panier').textContent=ops.length>0?fmt(tCA/ops.length):'—';
  document.getElementById('kv-ann').textContent=fmt(annTotal);
  document.getElementById('ks-ann').textContent=(ANN_SALES.length+ANN_OPS.length)+' dossiers';
}}

// ── OPS CHARTS ─────────────────────────────────────────────────────────────────
function renderOpsMonthly(ops) {{
  const m={{}};
  ops.forEach(r=>{{ if(!m[r.month]) m[r.month]={{ca:0,marge:0}}; m[r.month].ca+=r.ca; m[r.month].marge+=r.marge; }});
  const labels=OPS_MONTHS.filter(x=>m[x]);
  dc('opsM'); charts['opsM']=new Chart(document.getElementById('ch-ops-monthly'),{{
    type:'bar', data:{{ labels, datasets:[
      {{label:'CA Client',data:labels.map(l=>m[l].ca),backgroundColor:'rgba(124,92,252,0.7)',borderRadius:4}},
      {{label:'Marge',data:labels.map(l=>m[l].marge),backgroundColor:'rgba(62,207,142,0.7)',borderRadius:4}}
    ]}},
    options:{{responsive:true,maintainAspectRatio:false,plugins:{{legend:{{position:'top'}}}},scales:{{y:{{ticks:{{callback:v=>fmt(v)}}}}}}}}
  }});
}}

function renderOpsPie(ops) {{
  const ag={{}};
  ops.forEach(r=>ag[r.agent]=(ag[r.agent]||0)+r.ca);
  const entries=Object.entries(ag).sort((a,b)=>b[1]-a[1]);
  dc('opsPie'); charts['opsPie']=new Chart(document.getElementById('ch-ops-pie'),{{
    type:'doughnut', data:{{labels:entries.map(e=>e[0]),datasets:[{{data:entries.map(e=>e[1]),backgroundColor:PALETTE,borderWidth:0}}]}},
    options:{{responsive:true,maintainAspectRatio:false,plugins:{{legend:{{position:'right',labels:{{font:{{size:11}}}}}}}}}}
  }});
}}

function renderVC() {{
  const top=PRESTAS.slice(0,10);
  dc('vc'); charts['vc']=new Chart(document.getElementById('ch-vc'),{{
    type:'bar', data:{{labels:top.map(p=>p.name),datasets:[
      {{label:'CA Client',data:top.map(p=>p.ca),backgroundColor:'rgba(124,92,252,0.7)',borderRadius:4}},
      {{label:'Coût Presta',data:top.map(p=>p.cost),backgroundColor:'rgba(255,77,109,0.7)',borderRadius:4}}
    ]}},
    options:{{responsive:true,maintainAspectRatio:false,indexAxis:'y',plugins:{{legend:{{position:'top'}}}},scales:{{x:{{ticks:{{callback:v=>fmt(v)}}}}}}}}
  }});
}}

function renderScatter(ops) {{
  const agents={{}};
  ops.forEach(r=>{{ if(!agents[r.agent]) agents[r.agent]={{n:0,ca:0,m:0}}; agents[r.agent].n++; agents[r.agent].ca+=r.ca; agents[r.agent].m+=r.marge; }});
  const datasets=Object.entries(agents).map(([name,d],i)=>({{
    label:name, data:[{{x:d.n,y:d.ca>0?d.m/d.ca*100:0,r:Math.min(Math.sqrt(d.ca/600),26)+5}}],
    backgroundColor:PALETTE[i%PALETTE.length], borderWidth:0
  }}));
  document.getElementById('scatter-legend').innerHTML=Object.keys(agents).map((n,i)=>
    `<div class="legend-item"><div class="legend-dot" style="background:${{PALETTE[i%PALETTE.length]}}"></div>${{n}}</div>`).join('');
  dc('scatter'); charts['scatter']=new Chart(document.getElementById('ch-scatter'),{{
    type:'bubble', data:{{datasets}},
    options:{{responsive:true,maintainAspectRatio:false,plugins:{{legend:{{display:false}}}},
      scales:{{x:{{title:{{display:true,text:'Nb enregistrements'}}}},y:{{title:{{display:true,text:'Marge %'}},ticks:{{callback:v=>v+'%'}}}}}}}}
  }});
}}

function renderOpsAgentsLine(ops) {{
  const m={{}};
  ops.forEach(r=>{{ if(!m[r.month]) m[r.month]=Object.create(null); m[r.month][r.agent]=(m[r.month][r.agent]||0)+r.ca; }});
  const labels=OPS_MONTHS.filter(x=>m[x]);
  const agents=[...new Set(ops.map(r=>r.agent))];
  const agColors={{'MEHDI':'rgba(124,92,252,1)','IMED':'rgba(62,207,142,1)','MARWA DÉBARRAS':'rgba(247,201,72,1)'}};
  dc('opsAgLine'); charts['opsAgLine']=new Chart(document.getElementById('ch-ops-agents-line'),{{
    type:'line', data:{{labels,datasets:agents.map((ag,i)=>({{
      label:ag, data:labels.map(l=>m[l][ag]||0),
      borderColor:agColors[ag]||PALETTE[i], backgroundColor:(agColors[ag]||PALETTE[i]).replace('1)','0.1)'),
      tension:0.3, pointRadius:3, fill:false
    }}))}},
    options:{{responsive:true,maintainAspectRatio:false,plugins:{{legend:{{position:'top',labels:{{font:{{size:10}}}}}}}},scales:{{y:{{ticks:{{callback:v=>fmt(v)}}}}}}}}
  }});
}}

function renderTableAgentsOps(ops) {{
  const agents={{}};
  ops.forEach(r=>{{ if(!agents[r.agent]) agents[r.agent]={{months:new Set(),ca:0,marge:0}};
    agents[r.agent].months.add(r.month); agents[r.agent].ca+=r.ca; agents[r.agent].marge+=r.marge; }});
  document.getElementById('tb-agents-ops').innerHTML=Object.entries(agents).sort((a,b)=>b[1].ca-a[1].ca).map(([n,d])=>{{
    const mp=d.ca>0?d.marge/d.ca*100:0; const cost=d.ca-d.marge;
    const b=mp>=35?'badge-good':mp>=25?'badge-warn':'badge-bad';
    const s=mp>=35?'🌟 Excellent':mp>=25?'⚠️ Correct':'🔴 Faible';
    const months=d.months.size;
    return `<tr><td><strong>${{n}}</strong></td><td>${{months}}</td><td>${{fmtFull(d.ca)}}</td><td>${{fmtFull(cost)}}</td><td>${{fmtFull(d.marge)}}</td><td><span class="badge ${{b}}">${{mp.toFixed(1)}}%</span></td><td>${{fmtFull(d.ca/months)}}</td><td>${{s}}</td></tr>`;
  }}).join('');
}}

// ── SALES CHARTS ───────────────────────────────────────────────────────────────
function renderSalesBar(sales) {{
  const ag={{}};
  sales.forEach(r=>ag[r.agent]=(ag[r.agent]||0)+r.ca);
  const entries=Object.entries(ag).sort((a,b)=>b[1]-a[1]);
  dc('salesBar'); charts['salesBar']=new Chart(document.getElementById('ch-sales-bar'),{{
    type:'bar', data:{{labels:entries.map(e=>e[0]),datasets:[{{label:'CA',data:entries.map(e=>e[1]),backgroundColor:PALETTE,borderRadius:4}}]}},
    options:{{responsive:true,maintainAspectRatio:false,plugins:{{legend:{{display:false}}}},scales:{{y:{{ticks:{{callback:v=>fmt(v)}}}}}}}}
  }});
}}

function renderSalesLine(sales) {{
  const m={{}};
  sales.forEach(r=>{{ if(!m[r.month]) m[r.month]={{}}; m[r.month][r.agent]=(m[r.month][r.agent]||0)+r.ca; }});
  const labels=SALES_MONTHS.filter(x=>m[x]);
  const agents=[...new Set(sales.map(r=>r.agent))].slice(0,6);
  dc('salesLine'); charts['salesLine']=new Chart(document.getElementById('ch-sales-line'),{{
    type:'line', data:{{labels,datasets:agents.map((ag,i)=>({{
      label:ag, data:labels.map(l=>m[l]?.[ag]||0),
      borderColor:PALETTE[i].replace('0.8','1'), backgroundColor:PALETTE[i].replace('0.8','0.1'),
      tension:0.3, pointRadius:2, fill:false, borderWidth:2
    }}))}},
    options:{{responsive:true,maintainAspectRatio:false,plugins:{{legend:{{position:'top',labels:{{font:{{size:10}},usePointStyle:true}}}}}},scales:{{y:{{ticks:{{callback:v=>fmt(v)}}}},x:{{ticks:{{font:{{size:9}}}}}}}}}}
  }});
}}

function renderTableSales(sales) {{
  const ag={{}};
  sales.forEach(r=>{{ if(!ag[r.agent]) ag[r.agent]={{ca:0,months:new Set()}}; ag[r.agent].ca+=r.ca; ag[r.agent].months.add(r.month); }});
  const sorted=Object.entries(ag).sort((a,b)=>b[1].ca-a[1].ca);
  document.getElementById('tb-sales-agents').innerHTML=sorted.map(([n,d],i)=>{{
    const months=d.months.size; const avg=d.ca/months;
    const b=i===0?'badge-good':i<3?'badge-purple':'badge-warn';
    return `<tr><td>${{i+1}}</td><td><strong>${{n}}</strong></td><td><span style="color:var(--accent2)">${{fmtFull(d.ca)}}</span></td><td>${{months}}</td><td>${{fmtFull(avg)}}</td><td><span class="badge ${{b}}">${{i===0?'🥇 Leader':i<3?'🟢 Top':'🟡 Actif'}}</span></td></tr>`;
  }}).join('');
}}

// ── PROVIDERS ─────────────────────────────────────────────────────────────────
function renderProviders() {{
  const top8=PROVIDERS.slice(0,8);
  dc('provCA'); charts['provCA']=new Chart(document.getElementById('ch-prov-ca'),{{
    type:'bar', data:{{labels:top8.map(p=>p.name),datasets:[{{data:top8.map(p=>p.ca),backgroundColor:PALETTE,borderRadius:4,label:'CA €'}}]}},
    options:{{responsive:true,maintainAspectRatio:false,indexAxis:'y',plugins:{{legend:{{display:false}}}},scales:{{x:{{ticks:{{callback:v=>fmt(v)}}}}}}}}
  }});
  dc('provVol'); charts['provVol']=new Chart(document.getElementById('ch-prov-vol'),{{
    type:'bar', data:{{labels:top8.map(p=>p.name),datasets:[{{data:top8.map(p=>p.count),backgroundColor:PALETTE.map(c=>c.replace('0.8','0.6')),borderRadius:4,label:'Dossiers'}}]}},
    options:{{responsive:true,maintainAspectRatio:false,indexAxis:'y',plugins:{{legend:{{display:false}}}}}}
  }});
  dc('provPanier'); charts['provPanier']=new Chart(document.getElementById('ch-prov-panier'),{{
    type:'bar', data:{{labels:top8.map(p=>p.name),datasets:[{{data:top8.map(p=>p.ca/p.count),backgroundColor:'rgba(247,201,72,0.7)',borderRadius:4,label:'Panier €'}}]}},
    options:{{responsive:true,maintainAspectRatio:false,indexAxis:'y',plugins:{{legend:{{display:false}}}},scales:{{x:{{ticks:{{callback:v=>fmt(v)}}}}}}}}
  }});
  dc('provPie'); charts['provPie']=new Chart(document.getElementById('ch-prov-pie'),{{
    type:'doughnut', data:{{labels:PROVIDERS.map(p=>p.name),datasets:[{{data:PROVIDERS.map(p=>p.ca),backgroundColor:PALETTE,borderWidth:0}}]}},
    options:{{responsive:true,maintainAspectRatio:false,plugins:{{legend:{{position:'right',labels:{{font:{{size:10}}}}}}}}}}
  }});
}}

function renderTableProviders() {{
  const total=PROVIDERS.reduce((s,p)=>s+p.ca,0);
  document.getElementById('tb-providers').innerHTML=PROVIDERS.map((p,i)=>{{
    const panier=p.ca/p.count; const part=(p.ca/total*100).toFixed(1);
    const b=i<2?'badge-good':i<5?'badge-purple':'badge-warn';
    const perf=i===0?'🥇 Leader':i<3?'🟢 Fort':i<6?'🟡 Moyen':'⚪ Niche';
    return `<tr><td><strong>${{p.name}}</strong></td><td>${{fmtFull(p.ca)}}</td><td>${{p.count}}</td><td>${{fmtFull(panier)}}</td>
      <td><div style="display:flex;align-items:center;gap:8px">
        <div style="background:var(--border);border-radius:3px;height:5px;width:70px;overflow:hidden">
          <div style="height:5px;border-radius:3px;background:var(--accent);width:${{Math.min(p.ca/total*100*3,100)}}%"></div>
        </div>${{part}}%</div></td>
      <td style="font-size:11px;color:var(--muted)">${{(p.agents||[]).slice(0,3).join(', ')}}</td>
      <td><span class="badge ${{b}}">${{perf}}</span></td></tr>`;
  }}).join('');
}}

// ── PRESTATAIRES ──────────────────────────────────────────────────────────────
function renderPrestas() {{
  const top10=PRESTAS.slice(0,10);
  const colors=top10.map(p=>{{ const mp=p.cost>0?(p.ca-p.cost)/p.ca*100:0; return mp>=30?'rgba(62,207,142,0.7)':mp>=22?'rgba(247,201,72,0.7)':'rgba(255,77,109,0.7)'; }});
  dc('prestaVol'); charts['prestaVol']=new Chart(document.getElementById('ch-presta-vol'),{{
    type:'bar', data:{{labels:top10.map(p=>p.name),datasets:[{{data:top10.map(p=>p.count),backgroundColor:'rgba(124,92,252,0.7)',borderRadius:4,label:'Chantiers'}}]}},
    options:{{responsive:true,maintainAspectRatio:false,indexAxis:'y',plugins:{{legend:{{display:false}}}}}}
  }});
  dc('prestaMarge'); charts['prestaMarge']=new Chart(document.getElementById('ch-presta-marge'),{{
    type:'bar', data:{{labels:top10.map(p=>p.name),datasets:[{{data:top10.map(p=>p.cost>0?((p.ca-p.cost)/p.ca*100).toFixed(1):0),backgroundColor:colors,borderRadius:4,label:'Marge %'}}]}},
    options:{{responsive:true,maintainAspectRatio:false,indexAxis:'y',plugins:{{legend:{{display:false}}}},scales:{{x:{{ticks:{{callback:v=>v+'%'}}}}}}}}
  }});
}}

function renderTablePrestas() {{
  document.getElementById('tb-prestas').innerHTML=PRESTAS.map(p=>{{
    const marge=p.ca-p.cost; const mp=p.cost>0?marge/p.ca*100:0;
    const b=mp>=30?'badge-good':mp>=22?'badge-warn':'badge-bad';
    const perf=mp>=30?'🟢 Excellent':mp>=22?'🟡 Correct':'🔴 Sous cible';
    return `<tr><td><strong>${{p.name}}</strong></td><td>${{p.count}}</td><td>${{fmtFull(p.ca)}}</td><td>${{fmtFull(p.cost)}}</td><td>${{fmtFull(marge)}}</td><td><span class="badge ${{b}}">${{mp.toFixed(1)}}%</span></td><td>${{p.count>0?fmtFull(p.cost/p.count):'—'}}</td><td>${{perf}}</td></tr>`;
  }}).join('');
}}

// ── ANNULATIONS ───────────────────────────────────────────────────────────────
function renderAnnulations() {{
  const tS=ANN_SALES.reduce((s,a)=>s+a.ca,0);
  const tO=ANN_OPS.reduce((s,a)=>s+a.ca,0);
  const tAll=tS+tO;
  const totalSalesCA=SALES_MONTHS.reduce((s,m)=>s+Object.values(SALES_MONTHLY[m]||{{}}).reduce((ss,v)=>ss+v,0),0);
  document.getElementById('ann-sales-total').textContent=fmt(tS);
  document.getElementById('ann-sales-count').textContent=ANN_SALES.length+' dossiers';
  document.getElementById('ann-ops-total').textContent=fmt(tO);
  document.getElementById('ann-ops-count').textContent=ANN_OPS.length+' dossiers';
  document.getElementById('ann-total').textContent=fmt(tAll);
  document.getElementById('ann-rate').textContent=totalSalesCA>0?(tS/totalSalesCA*100).toFixed(1)+'%':'—';

  document.getElementById('ann-sales-list').innerHTML=ANN_SALES.map(a=>
    `<div class="ann-row"><div><strong>${{a.client}}</strong><div class="ann-meta">${{a.month}}${{a.provider&&a.provider!=='Autre'?' · '+a.provider:''}}${{a.agent?' · '+a.agent:''}}</div></div><div class="ann-ca">${{fmt(a.ca)}}</div></div>`
  ).join('') || '<p style="color:var(--muted);font-size:13px">Aucune annulation détectée.</p>';

  document.getElementById('ann-ops-list').innerHTML=ANN_OPS.map(a=>
    `<div class="ann-row"><div><strong>${{a.client}}</strong><div class="ann-meta">${{a.month}}${{a.agent?' · '+a.agent:''}}</div></div><div class="ann-ca" style="color:var(--accent2)">${{fmt(a.ca)}}</div></div>`
  ).join('') || '<p style="color:var(--muted);font-size:13px">Aucune annulation OPS détectée.</p>';

  // Graphe par provider
  const provAnn={{}};
  ANN_SALES.forEach(a=>provAnn[a.provider||'Autre']=(provAnn[a.provider||'Autre']||0)+a.ca);
  const entries=Object.entries(provAnn).sort((a,b)=>b[1]-a[1]);
  dc('annProv'); charts['annProv']=new Chart(document.getElementById('ch-ann-prov'),{{
    type:'bar', data:{{labels:entries.map(e=>e[0]),datasets:[{{data:entries.map(e=>e[1]),backgroundColor:'rgba(255,77,109,0.7)',borderRadius:4,label:'CA Perdu'}}]}},
    options:{{responsive:true,maintainAspectRatio:false,indexAxis:'y',plugins:{{legend:{{display:false}}}},scales:{{x:{{ticks:{{callback:v=>fmt(v)}}}}}}}}
  }});

  // Analyse
  const topAnn=ANN_SALES.length>0?ANN_SALES[0]:null;
  const dupClients={{}};
  ANN_SALES.forEach(a=>dupClients[a.client]=(dupClients[a.client]||0)+1);
  const dups=Object.entries(dupClients).filter(([,n])=>n>1);
  document.getElementById('ann-analysis').innerHTML=`
    <div style="font-family:var(--font-display);font-size:15px;font-weight:700;margin-bottom:14px;color:var(--danger)">🔍 Analyse des annulations</div>
    ${{topAnn?`<div class="alert-item"><div class="alert-icon">📌</div><div class="alert-text"><strong>Dossier le plus impactant</strong><span>${{topAnn.client}} — ${{fmt(topAnn.ca)}} (${{topAnn.month}}, ${{topAnn.provider||'?'}})</span></div></div>`:''}}
    ${{dups.length>0?`<div class="alert-item"><div class="alert-icon">🔄</div><div class="alert-text"><strong>Client(s) annulé(s) plusieurs fois</strong><span>${{dups.map(([c,n])=>c+' (×'+n+')').join(', ')}} — À investiguer : problème prestataire récurrent ou client difficile ?</span></div></div>`:''}}
    <div class="alert-item"><div class="alert-icon">💡</div><div class="alert-text"><strong>Taux global — Surveiller l'évolution mensuelle</strong><span>Mettre en place un suivi mensuel des annulations pour détecter les pics et identifier les causes (prestataire, délai, qualification).</span></div></div>`;
}}

// ── ALERTES ───────────────────────────────────────────────────────────────────
function renderAlertes(ops,sales) {{
  const agents={{}};
  ops.forEach(r=>{{ if(!agents[r.agent]) agents[r.agent]={{ca:0,marge:0,n:0}};
    agents[r.agent].ca+=r.ca; agents[r.agent].marge+=r.marge; agents[r.agent].n++; }});
  const low=Object.entries(agents).map(([n,d])=>{{return{{name:n,mp:d.ca>0?d.marge/d.ca*100:0,ca:d.ca,n:d.n}};}}).filter(a=>a.mp<25&&a.ca>3000).sort((a,b)=>a.mp-b.mp);
  const top=Object.entries(agents).map(([n,d])=>{{return{{name:n,mp:d.ca>0?d.marge/d.ca*100:0,ca:d.ca,n:d.n}};}}).filter(a=>a.mp>=30).sort((a,b)=>b.mp-a.mp);
  const topProv=PROVIDERS[0];
  const lowPresta=PRESTAS.filter(p=>p.cost>0&&(p.ca-p.cost)/p.ca*100<22&&p.count>=3);
  document.getElementById('alertes-container').innerHTML=`
  <div class="grid-2" style="margin-bottom:20px">
    <div class="alert-box" style="background:rgba(255,77,109,0.08);border-color:rgba(255,77,109,0.3)">
      <div style="font-family:var(--font-display);font-size:15px;font-weight:700;margin-bottom:14px;color:var(--danger)">⚠️ Agents OPS sous cible</div>
      ${{low.length===0?'<p style="color:var(--muted);font-size:13px">✅ Aucun agent sous le seuil de 25%.</p>':low.map(a=>`<div class="alert-item"><div class="alert-icon">🔴</div><div class="alert-text"><strong>${{a.name}}</strong><span>Marge <b style="color:var(--danger)">${{a.mp.toFixed(1)}}%</b> · CA ${{fmt(a.ca)}}</span></div></div>`).join('')}}
    </div>
    <div class="alert-box" style="background:rgba(62,207,142,0.06);border-color:rgba(62,207,142,0.3)">
      <div style="font-family:var(--font-display);font-size:15px;font-weight:700;margin-bottom:14px;color:var(--accent3)">✅ Top Performers OPS</div>
      ${{top.length===0?'<p style="color:var(--muted);font-size:13px">Filtrez sur plus de périodes.</p>':top.map(a=>`<div class="alert-item"><div class="alert-icon">🌟</div><div class="alert-text"><strong>${{a.name}}</strong><span>Marge <b style="color:var(--accent3)">${{a.mp.toFixed(1)}}%</b> · CA ${{fmt(a.ca)}}</span></div></div>`).join('')}}
    </div>
  </div>
  <div class="alert-box" style="background:rgba(124,92,252,0.06);border-color:rgba(124,92,252,0.3)">
    <div style="font-family:var(--font-display);font-size:15px;font-weight:700;margin-bottom:14px;color:var(--accent)">📋 Synthèse Stratégique</div>
    ${{topProv?`<div class="alert-item"><div class="alert-icon">📦</div><div class="alert-text"><strong>Provider dominant : ${{topProv.name}}</strong><span>${{fmtFull(topProv.ca)}} · ${{topProv.count}} dossiers — Dépendance forte, surveiller les annulations issues de cette source.</span></div></div>`:''}}
    ${{lowPresta.length>0?`<div class="alert-item"><div class="alert-icon">🔧</div><div class="alert-text"><strong>Prestataires à renégocier</strong><span>${{lowPresta.map(p=>p.name+' ('+((p.ca-p.cost)/p.ca*100).toFixed(1)+'%)').join(', ')}} — Taux de marge sous le seuil de 22%.</span></div></div>`:''}}
    <div class="alert-item"><div class="alert-icon">🧹</div><div class="alert-text"><strong>Segment Débarras — Le plus rentable</strong><span>Marges structurellement plus élevées que le déménagement. Développer ce segment est une priorité.</span></div></div>
    <div class="alert-item"><div class="alert-icon">📅</div><div class="alert-text"><strong>Saisonnalité Q2 — Préparer les capacités</strong><span>Mai-Juin représentent le pic historique. Anticiper les prestataires dès mars.</span></div></div>
  </div>`;
}}



function renderSegments() {{
  const km = KPI_MONTHS.filter(m => KPI_GLOBAL[m]);
  if(!km.length) return;

  const demCA    = km.map(m => KPI_GLOBAL[m].ca_dem   || 0);
  const debCA    = km.map(m => KPI_GLOBAL[m].ca_deb   || 0);
  const demMarge = km.map(m => KPI_GLOBAL[m].marge_dem || 0);
  const debMarge = km.map(m => KPI_GLOBAL[m].marge_deb || 0);
  const ns       = km.map(m => KPI_GLOBAL[m].n        || 0);

  const totDemCA    = demCA.reduce((s,v)=>s+v,0);
  const totDebCA    = debCA.reduce((s,v)=>s+v,0);
  const totDemMarge = demMarge.reduce((s,v)=>s+v,0);
  const totDebMarge = debMarge.reduce((s,v)=>s+v,0);
  const totN        = ns.reduce((s,v)=>s+v,0);
  const totCA       = totDemCA + totDebCA;
  const totMarge    = totDemMarge + totDebMarge;
  const mpDem       = totDemCA>0 ? totDemMarge/totDemCA*100 : 0;
  const mpDeb       = totDebCA>0 ? totDebMarge/totDebCA*100 : 0;
  const mpGlob      = totCA>0    ? totMarge/totCA*100 : 0;
  const shareDem    = totCA>0 ? totDemCA/totCA*100 : 0;
  const shareDeb    = totCA>0 ? totDebCA/totCA*100 : 0;

  // KPI cards
  document.getElementById('seg-kpis').innerHTML = [
    {{l:'CA Déménagement',       v:fmt(totDemCA),   sub:'Part : '+shareDem.toFixed(0)+'%',  c:'var(--accent)'}},
    {{l:'CA Débarras & Ménage',  v:fmt(totDebCA),   sub:'Part : '+shareDeb.toFixed(0)+'%',  c:'var(--accent3)'}},
    {{l:'Marge % Déménagement',  v:mpDem.toFixed(1)+'%', sub:fmt(totDemMarge)+' de marge',   c:'var(--accent)'}},
    {{l:'Marge % Débarras',      v:mpDeb.toFixed(1)+'%', sub:fmt(totDebMarge)+' de marge',   c:'var(--accent3)'}},
    {{l:'Écart de marge (pts)',   v:'+'+(mpDeb-mpDem).toFixed(1)+'pts', sub:'Débarras plus rentable', c:'var(--accent2)'}},
    {{l:'Total chantiers',        v:totN,             sub:km.length+' mois de données',       c:'var(--muted)'}},
  ].map(k=>`<div class="kpi-card"><div class="kpi-label">${{k.l}}</div><div class="kpi-value" style="color:${{k.c}}">${{k.v}}</div><div class="kpi-sub">${{k.sub}}</div></div>`).join('');

  // Chart 1 — CA mensuel stacked
  const ctx1 = document.getElementById('segCaChart').getContext('2d');
  if(window._segCaChart) window._segCaChart.destroy();
  window._segCaChart = new Chart(ctx1, {{
    type:'bar',
    data:{{
      labels:km,
      datasets:[
        {{label:'Déménagement', data:demCA, backgroundColor:'rgba(124,92,252,0.75)', borderRadius:3}},
        {{label:'Débarras & Ménage', data:debCA, backgroundColor:'rgba(62,207,142,0.75)', borderRadius:3}},
      ]
    }},
    options:{{
      responsive:true, plugins:{{legend:{{labels:{{color:'#aaa'}}}},tooltip:{{callbacks:{{label:ctx=>ctx.dataset.label+' : '+fmt(ctx.raw)}}}}}},
      scales:{{
        x:{{stacked:true,ticks:{{color:'#888'}},grid:{{color:'rgba(255,255,255,0.05)'}}}},
        y:{{stacked:true,ticks:{{color:'#888',callback:v=>fmt(v)}},grid:{{color:'rgba(255,255,255,0.05)'}}}}
      }}
    }}
  }});

  // Chart 2 — Marge mensuelle stacked
  const ctx2 = document.getElementById('segMargeChart').getContext('2d');
  if(window._segMargeChart) window._segMargeChart.destroy();
  window._segMargeChart = new Chart(ctx2, {{
    type:'bar',
    data:{{
      labels:km,
      datasets:[
        {{label:'Marge Déménagement', data:demMarge, backgroundColor:'rgba(124,92,252,0.75)', borderRadius:3}},
        {{label:'Marge Débarras & Ménage', data:debMarge, backgroundColor:'rgba(62,207,142,0.75)', borderRadius:3}},
      ]
    }},
    options:{{
      responsive:true, plugins:{{legend:{{labels:{{color:'#aaa'}}}},tooltip:{{callbacks:{{label:ctx=>ctx.dataset.label+' : '+fmt(ctx.raw)}}}}}},
      scales:{{
        x:{{stacked:true,ticks:{{color:'#888'}},grid:{{color:'rgba(255,255,255,0.05)'}}}},
        y:{{stacked:true,ticks:{{color:'#888',callback:v=>fmt(v)}},grid:{{color:'rgba(255,255,255,0.05)'}}}}
      }}
    }}
  }});

  // Chart 3 — Donut CA répartition
  const ctx3 = document.getElementById('segDonutChart').getContext('2d');
  if(window._segDonutChart) window._segDonutChart.destroy();
  window._segDonutChart = new Chart(ctx3, {{
    type:'doughnut',
    data:{{
      labels:['Déménagement','Débarras & Ménage'],
      datasets:[{{data:[totDemCA,totDebCA],backgroundColor:['rgba(124,92,252,0.85)','rgba(62,207,142,0.85)'],borderWidth:0}}]
    }},
    options:{{
      responsive:true,
      plugins:{{
        legend:{{labels:{{color:'#aaa'}}}},
        tooltip:{{callbacks:{{label:ctx=>ctx.label+' : '+fmt(ctx.raw)+' ('+ctx.parsed.toFixed(0)+'%)'}}}},
      }}
    }}
  }});

  // Chart 4 — Marge % par mois comparée (line)
  const mpDemLine = km.map((m,i)=> demCA[i]>0 ? demMarge[i]/demCA[i]*100 : null);
  const mpDebLine = km.map((m,i)=> debCA[i]>0 ? debMarge[i]/debCA[i]*100 : null);
  const ctx4 = document.getElementById('segMargePctChart').getContext('2d');
  if(window._segMargePctChart) window._segMargePctChart.destroy();
  window._segMargePctChart = new Chart(ctx4, {{
    type:'line',
    data:{{
      labels:km,
      datasets:[
        {{label:'Marge % Déménagement', data:mpDemLine, borderColor:'rgba(124,92,252,1)', backgroundColor:'rgba(124,92,252,0.1)', tension:0.3, fill:true, pointRadius:3}},
        {{label:'Marge % Débarras', data:mpDebLine, borderColor:'rgba(62,207,142,1)', backgroundColor:'rgba(62,207,142,0.1)', tension:0.3, fill:true, pointRadius:3}},
      ]
    }},
    options:{{
      responsive:true,
      plugins:{{legend:{{labels:{{color:'#aaa'}}}},tooltip:{{callbacks:{{label:ctx=>ctx.dataset.label+' : '+(ctx.raw||0).toFixed(1)+'%'}}}}}},
      scales:{{
        x:{{ticks:{{color:'#888'}},grid:{{color:'rgba(255,255,255,0.05)'}}}},
        y:{{ticks:{{color:'#888',callback:v=>v+'%'}},grid:{{color:'rgba(255,255,255,0.05)'}},suggestedMin:0,suggestedMax:60}}
      }}
    }}
  }});

  // Table détaillée
  const tbl = document.getElementById('seg-table');
  tbl.innerHTML = `
    <table>
      <thead><tr>
        <th>Mois</th>
        <th>CA Déménagement</th><th>Marge DEM</th><th>Marge % DEM</th>
        <th>CA Débarras</th><th>Marge DEB</th><th>Marge % DEB</th>
        <th>CA Global</th><th>Marge Global</th><th>Marge %</th><th>N</th>
      </tr></thead>
      <tbody>
        ${{km.map((m,i)=>{{
          const cd=demCA[i], md=demMarge[i], cb=debCA[i], mb=debMarge[i];
          const cg=cd+cb, mg=md+mb;
          const pd=cd>0?md/cd*100:0, pb=cb>0?mb/cb*100:0, pg=cg>0?mg/cg*100:0;
          return `<tr>
            <td><strong>${{m}}</strong></td>
            <td>${{fmt(cd)}}</td><td>${{fmt(md)}}</td>
            <td><span class="badge ${{pd>=25?'badge-good':pd>=20?'badge-warn':'badge-bad'}}">${{pd.toFixed(1)}}%</span></td>
            <td>${{fmt(cb)}}</td><td>${{fmt(mb)}}</td>
            <td><span class="badge ${{pb>=40?'badge-good':pb>=25?'badge-warn':'badge-bad'}}">${{pb.toFixed(1)}}%</span></td>
            <td>${{fmt(cg)}}</td><td>${{fmt(mg)}}</td>
            <td><span class="badge ${{pg>=30?'badge-good':pg>=22?'badge-warn':'badge-bad'}}">${{pg.toFixed(1)}}%</span></td>
            <td>${{KPI_GLOBAL[m].n}}</td>
          </tr>`;
        }}).join('')}}
        <tr style="font-weight:800;background:rgba(255,255,255,0.04)">
          <td>TOTAL</td>
          <td>${{fmt(totDemCA)}}</td><td>${{fmt(totDemMarge)}}</td>
          <td><span class="badge badge-good">${{mpDem.toFixed(1)}}%</span></td>
          <td>${{fmt(totDebCA)}}</td><td>${{fmt(totDebMarge)}}</td>
          <td><span class="badge badge-good">${{mpDeb.toFixed(1)}}%</span></td>
          <td>${{fmt(totCA)}}</td><td>${{fmt(totMarge)}}</td>
          <td><span class="badge badge-good">${{mpGlob.toFixed(1)}}%</span></td>
          <td>${{totN}}</td>
        </tr>
      </tbody>
    </table>`;
}}

function renderMcKinsey(ops, sales) {{
  const ag = {{}};
  ops.forEach(r => {{
    if(!ag[r.agent]) ag[r.agent]={{ca:0,marge:0,n:0}};
    ag[r.agent].ca+=r.ca; ag[r.agent].marge+=r.marge; ag[r.agent].n++;
  }});
  const tCA = ops.reduce((s,r)=>s+r.ca,0);
  const tM  = ops.reduce((s,r)=>s+r.marge,0);
  const tS  = sales.reduce((s,r)=>s+r.ca,0);
  const tA  = ANN_SALES.reduce((s,a)=>s+a.ca,0)+ANN_OPS.reduce((s,a)=>s+a.ca,0);
  const mp  = tCA>0?tM/tCA*100:0;
  const totProv = PROVIDERS.reduce((s,p)=>s+p.ca,0);
  const top1s = totProv>0?PROVIDERS[0].ca/totProv*100:0;
  const top2s = totProv>0?PROVIDERS.slice(0,2).reduce((s,p)=>s+p.ca,0)/totProv*100:0;
  const lowP  = PRESTAS.filter(p=>p.cost>0&&(p.ca-p.cost)/p.ca*100<25&&p.count>=5);
  const agArr = Object.entries(ag).map(([n,d])=>({{name:n,mp:d.ca>0?d.marge/d.ca*100:0,ca:d.ca,n:d.n}}));
  const mCa={{}}; OPS_MONTHS.forEach(m=>{{mCa[m]=ops.filter(r=>r.month===m).reduce((s,r)=>s+r.ca,0);}});
  const mm=OPS_MONTHS.filter(x=>mCa[x]>0);
  const lM=mm[mm.length-1]; const pM=mm[mm.length-2];
  const trend=pM&&lM&&mCa[pM]>0?(mCa[lM]-mCa[pM])/mCa[pM]*100:0;
  const annR=tS>0?ANN_SALES.reduce((s,a)=>s+a.ca,0)/tS*100:0;

  const ksis=[
    {{l:'Marge OPS globale',v:mp.toFixed(1)+'%',t:'>32%',ok:mp>=32}},
    {{l:'Taux annulation Sales',v:annR.toFixed(1)+'%',t:'<3%',ok:annR<3}},
    {{l:'Concentration provider #1',v:top1s.toFixed(0)+'%',t:'<35%',ok:top1s<35}},
    {{l:'Tendance CA OPS vs M-1',v:(trend>=0?'+':'')+trend.toFixed(1)+'%',t:'>0%',ok:trend>=0}},
  ];

  const Q=[
    {{t:'🟢 AGIR MAINTENANT',bg:'rgba(62,207,142,0.08)',b:'rgba(62,207,142,0.3)',items:[
      mp<32?'Renégocier les prestas à faible marge — Chaque +1pt = '+fmt(tCA*0.01)+' de marge supplémentaire':'',
      lowP.length>0?'Prestas sous-performants : '+lowP.map(p=>p.name).join(', ')+' — en dessous de 25%':'',
      top2s>55?'Diversifier les sources — Top 2 providers = '+top2s.toFixed(0)+'% du CA Sales. Risque de concentration':'',
      annR>3?'Réduire taux annulation ('+annR.toFixed(1)+'%) — '+fmt(tA)+' perdus depuis origine':'',
    ].filter(Boolean)}},
    {{t:'🟣 PLANIFIER',bg:'rgba(124,92,252,0.08)',b:'rgba(124,92,252,0.3)',items:[
      'Développer le segment Débarras — Marge structurellement +8-10pts vs Déménagement',
      'Préparer Q2 2026 : sécuriser prestataires dès Mars pour pic Mai-Juin',
      'Activer LAD, Maison Débarras, Bon Débarras — moins de 2% du CA actuellement',
    ]}},
    {{t:'🟡 SURVEILLER',bg:'rgba(247,201,72,0.08)',b:'rgba(247,201,72,0.3)',items:[
      'Montée en compétence AMENI (OPS depuis Jan 26) — suivre ratio chantiers/marge',
      'Performance mensuelle Nadia & Molka — agents Sales en croissance rapide',
      'Évolution CA par provider Matchmove ADS vs SEO — optimiser allocation budget',
    ]}},
    {{t:'🔴 RISQUES À ANTICIPER',bg:'rgba(255,77,109,0.06)',b:'rgba(255,77,109,0.25)',items:[
      'Dépendance Officiel du Dém. ('+top1s.toFixed(0)+'% CA) — risque si partenariat rompu',
      'MEHDI + IMED = 77% CA OPS — former AMENI comme relève opérationnelle',
      'Pic annulations Mai 2025 (10 dossiers) — risque récidive sans process de qualification',
    ]}},
  ];

  const bcgCols=[
    {{share:'>20%',panier:'>1000€',label:'⭐ Vache à lait',c:'rgba(62,207,142,0.12)'}},
    {{share:'8-20%',panier:'>1000€',label:'🚀 Étoile montante',c:'rgba(124,92,252,0.12)'}},
    {{share:'<8%',panier:'>1200€',label:'❓ À développer',c:'rgba(247,201,72,0.12)'}},
    {{share:'<8%',panier:'<1000€',label:'🐕 Faible potentiel',c:'rgba(255,77,109,0.08)'}},
  ];

  const plans=[
    {{p:'J+30 — Mars 2026',c:'rgba(255,77,109,0.1)',b:'rgba(255,77,109,0.3)',items:[
      'Audit annulations Mai 2025 — identifier cause racine (presta ou qualification)',
      'Renégocier prestas < 25% marge — objectif +2pts minimum',
      'Fixer objectif mensuel AMENI : 10 chantiers, marge > 28%',
    ]}},
    {{p:'J+60 — Avril 2026',c:'rgba(247,201,72,0.08)',b:'rgba(247,201,72,0.3)',items:[
      'Activer 2 nouveaux providers alternatifs (LAD, Maison Débarras)',
      'Briefer agents Sales sur qualification stricte avant prise de commande',
      'Bilan Q1 2026 vs objectif annuel — ajuster si nécessaire',
    ]}},
    {{p:'J+90 — Mai 2026',c:'rgba(62,207,142,0.06)',b:'rgba(62,207,142,0.3)',items:[
      'Capacité prestataires confirmée pour pic Q2 (Mai-Juin)',
      'Marge OPS > 32% atteinte (vs 30.8% actuellement)',
      "Dashboard utilisé par toute l&#39;équipe comme outil de pilotage",
    ]}},
  ];

  const risks=[
    ['Perte provider Officiel du Dém. ('+top1s.toFixed(0)+'%)','Faible','Critique','Développer 3 providers alternatifs > 10% chacun'],
    ['Pic Q2 sans capacité prestataire','Moyenne','Élevé','Confirmer engagements de volume en Mars'],
    ['Annulations > 5% sans amélioration qualification','Moyenne','Moyen','Grille de qualification + formation agents Sales'],
    ['Départ agent OPS clé (MEHDI/IMED = 77% CA)','Faible','Critique','Former AMENI, documenter process'],
    ['Compression marges par pression concurrentielle','Moyenne','Moyen','Segmenter offre premium vs standard'],
  ];

  const c=document.getElementById('mckinsey-container');
  c.innerHTML=
    '<div style="font-family:var(--font-display);font-size:22px;font-weight:800;margin-bottom:6px">Framework d&#39;aide à la décision</div>'+
    '<div style="font-size:12px;color:var(--muted);margin-bottom:28px;letter-spacing:1px">Analyse structurée · Priorités d&#39;action · Impact business estimé</div>'+

    '<div style="background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:24px;margin-bottom:20px">'+
    '<div style="font-family:var(--font-display);font-size:16px;font-weight:700;margin-bottom:18px">📈 1. Indicateurs Clés de Performance</div>'+
    '<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:14px">'+
    ksis.map(k=>'<div style="background:var(--surface2);border-radius:10px;padding:16px;border:1px solid '+(k.ok?'rgba(62,207,142,0.3)':'rgba(255,77,109,0.3)')+'">'+
      '<div style="font-size:10px;color:var(--muted);letter-spacing:1px;text-transform:uppercase;margin-bottom:8px">'+k.l+'</div>'+
      '<div style="font-family:var(--font-display);font-size:26px;font-weight:800;color:'+(k.ok?'var(--accent3)':'var(--danger)')+'">'+k.v+'</div>'+
      '<div style="font-size:11px;color:var(--muted);margin-top:4px">Cible : '+k.t+' '+(k.ok?'✅':'⚠️')+'</div></div>'
    ).join('')+'</div></div>'+

    '<div style="background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:24px;margin-bottom:20px">'+
    '<div style="font-family:var(--font-display);font-size:16px;font-weight:700;margin-bottom:18px">📊 2. Matrice Priorité / Impact</div>'+
    '<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">'+
    Q.map(q=>'<div style="background:'+q.bg+';border:1px solid '+q.b+';border-radius:10px;padding:18px">'+
      '<div style="font-weight:700;font-size:13px;margin-bottom:12px">'+q.t+'</div>'+
      (q.items.length===0?'<div style="font-size:12px;color:var(--muted)">✅ Aucune action requise sur ce quadrant</div>':
      q.items.map(i=>'<div style="display:flex;gap:8px;margin-bottom:7px;font-size:12px"><span style="flex-shrink:0">→</span><span>'+i+'</span></div>').join(''))
    +'</div>').join('')+'</div></div>'+

    '<div style="background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:24px;margin-bottom:20px">'+
    '<div style="font-family:var(--font-display);font-size:16px;font-weight:700;margin-bottom:18px">🗂️ 3. Portefeuille Providers — Matrice BCG</div>'+
    '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:10px">'+
    PROVIDERS.map((p,i)=>{{
      const sh=totProv>0?p.ca/totProv*100:0;
      const pan=p.ca/Math.max(1,p.count);
      let star,col;
      if(sh>20&&pan>=1000){{star='⭐ Vache à lait';col='rgba(62,207,142,0.12)';}}
      else if(sh>8&&pan>=1000){{star='🚀 Étoile montante';col='rgba(124,92,252,0.12)';}}
      else if(sh<=8&&pan>=1200){{star='❓ À développer';col='rgba(247,201,72,0.12)';}}
      else{{star='🐕 Faible potentiel';col='rgba(255,77,109,0.08)';}}
      return '<div style="background:'+col+';border:1px solid var(--border);border-radius:8px;padding:12px">'+
        '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">'+
        '<strong>'+p.name+'</strong><span style="font-size:11px">'+star+'</span></div>'+
        '<div style="font-size:11px;color:var(--muted)">'+sh.toFixed(1)+'% du CA · '+p.count+' dossiers · Panier '+fmt(pan)+'</div></div>';
    }}).join('')+'</div></div>'+

    '<div style="background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:24px;margin-bottom:20px">'+
    '<div style="font-family:var(--font-display);font-size:16px;font-weight:700;margin-bottom:18px">🗓️ 4. Plan d&#39;action — 90 jours</div>'+
    '<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px">'+
    plans.map(q=>'<div style="background:'+q.c+';border:1px solid '+q.b+';border-radius:10px;padding:16px">'+
      '<div style="font-weight:700;font-size:13px;margin-bottom:12px">'+q.p+'</div>'+
      q.items.map(i=>'<div style="display:flex;gap:8px;margin-bottom:8px;font-size:12px"><span>→</span><span>'+i+'</span></div>').join('')
    +'</div>').join('')+'</div></div>'+

    '<div style="background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:24px">'+
    '<div style="font-family:var(--font-display);font-size:16px;font-weight:700;margin-bottom:18px">⚡ 5. Registre des risques</div>'+
    '<table style="width:100%;border-collapse:collapse">'+
    '<thead><tr>'+['Risque','Probabilité','Impact','Mitigation'].map(h=>
      '<th style="text-align:left;padding:10px 14px;font-size:10px;letter-spacing:1.5px;color:var(--muted);border-bottom:1px solid var(--border);background:var(--surface2);text-transform:uppercase">'+h+'</th>'
    ).join('')+'</tr></thead><tbody>'+
    risks.map(([r,p,imp,m])=>'<tr>'+
      '<td style="padding:10px 14px;font-size:13px;border-bottom:1px solid rgba(42,42,61,0.4)">'+r+'</td>'+
      '<td style="padding:10px 14px;border-bottom:1px solid rgba(42,42,61,0.4)"><span class="badge '+(p==='Faible'?'badge-good':'badge-warn')+'">'+p+'</span></td>'+
      '<td style="padding:10px 14px;border-bottom:1px solid rgba(42,42,61,0.4)"><span class="badge '+(imp==='Critique'?'badge-bad':'badge-warn')+'">'+imp+'</span></td>'+
      '<td style="padding:10px 14px;font-size:12px;color:var(--muted);border-bottom:1px solid rgba(42,42,61,0.4)">'+m+'</td>'+
    '</tr>').join('')+'</tbody></table></div>';
}}

function showTab(id,btn) {{
  document.querySelectorAll('.tab-panel').forEach(p=>p.classList.remove('active'));
  document.querySelectorAll('.tab').forEach(t=>t.classList.remove('active'));
  document.getElementById(id).classList.add('active'); btn.classList.add('active');
}}

populateFilters();
applyFilters();
</script>
</body>
</html>"""

# ─── ÉCRITURE ──────────────────────────────────────────────────────────────────
OUTPUT_FILE = os.path.join(SCRIPT_DIR, "dashboard_matchmove.html")
with open(OUTPUT_FILE, 'w', encoding='utf-8') as f:
    f.write(html)

print(f"✅ Dashboard généré : {OUTPUT_FILE}")
print()
print("╔══════════════════════════════════════════════════╗")
print("║  ✅  TERMINÉ — Ouvre dashboard_matchmove.html    ║")
print("╚══════════════════════════════════════════════════╝")
